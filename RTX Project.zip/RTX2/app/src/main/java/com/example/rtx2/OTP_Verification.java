package com.example.rtx2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class OTP_Verification extends AppCompatActivity {

    private static TextView go_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_t_p__verification);
        onClickgoBack();
    }

    public void onClickgoBack(){
        go_back = (TextView)findViewById(R.id.textView11);
        go_back.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(".Signup");
                        startActivity(intent);
                    }
                }
        );
    }
}